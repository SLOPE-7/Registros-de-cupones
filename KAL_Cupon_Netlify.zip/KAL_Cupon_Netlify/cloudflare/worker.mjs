// KAL en Cloudflare: un solo Worker que
//   - sirve la app (carpeta site/) como archivos estáticos;
//   - atiende las funciones en /api/<nombre> (y las rutas antiguas /.netlify/functions/<nombre>, por compatibilidad);
//   - envía los avisos de partidos cada 5 minutos (tarea programada).
// Variables y secretos (Cloudflare → Workers → kal-cupones → Settings → Variables and Secrets):
//   API_FOOTBALL_KEY, ANTHROPIC_API_KEY, ANALISTA_CLAVE, FOOTBALL_DATA_KEY y, opcional, THESPORTSDB_KEY.
import { DurableObject } from "cloudflare:workers";
import Anthropic from "@anthropic-ai/sdk";
import escudos from "../servidor/escudos.mjs";
import logo from "../servidor/logo.mjs";
import partido from "../servidor/partido.mjs";
import jugadores from "../servidor/jugadores.mjs";
import catalogo from "../servidor/catalogo.mjs";
import imagenes from "../servidor/imagenes.mjs";
import { manejar as analista } from "../servidor/analista.mjs";
import { manejar as enlace } from "../servidor/enlace.mjs";
import { avisosHandler, enviarAvisos } from "./avisos.mjs";
import { datosPartido } from "./datos-partido.mjs";
import { buscarLogos } from "../servidor/buscar-logos.mjs";

// Almacenamiento de los avisos (suscripciones, partidos y claves VAPID). Un único Durable Object con SQLite,
// incluido en el plan gratis y sin nada que configurar.
export class Almacen extends DurableObject {
  async leer(clave) {
    return (await this.ctx.storage.get(clave)) ?? null;
  }
  async guardar(clave, valor) {
    await this.ctx.storage.put(clave, valor);
  }
  async borrar(clave) {
    await this.ctx.storage.delete(clave);
  }
  async listar(prefijo) {
    return [...(await this.ctx.storage.list({ prefix: prefijo })).keys()];
  }
}
function almacen(env) {
  const stub = env.ALMACEN.get(env.ALMACEN.idFromName("kal-avisos"));
  return {
    get: (k) => stub.leer(k),
    put: (k, v) => stub.guardar(k, v),
    delete: (k) => stub.borrar(k),
    list: (p) => stub.listar(p),
  };
}

// Las funciones de servidor/ leen sus claves de process.env.
function exponerVariables(env) {
  globalThis.process ??= { env: {} };
  process.env ??= {};
  for (const k of ["API_FOOTBALL_KEY", "THESPORTSDB_KEY"])
    if (typeof env[k] === "string") process.env[k] = env[k];
}

const FUNCIONES = { escudos, logo, partido, jugadores, catalogo, imagenes };

async function api(nombre, request, env) {
  if (FUNCIONES[nombre]) return FUNCIONES[nombre](request);
  if (nombre === "avisos") return avisosHandler(request, almacen(env));
  if (nombre === "enlace") return enlace(request, { env: { ANALISTA_CLAVE: env.ANALISTA_CLAVE } });
  if (nombre === "buscar-logo")
    return buscarLogos(request, {
      footballDataKey: env.FOOTBALL_DATA_KEY,
      theSportsDbKey: /^[A-Za-z0-9]{1,40}$/.test(env.THESPORTSDB_KEY || "") ? env.THESPORTSDB_KEY : "123",
      store: almacen(env),
    });
  if (nombre === "datos-partido")
    return datosPartido(request, { token: env.FOOTBALL_DATA_KEY, store: almacen(env) });
  if (nombre === "analista")
    return analista(request, {
      env: { ANTHROPIC_API_KEY: env.ANTHROPIC_API_KEY, ANALISTA_CLAVE: env.ANALISTA_CLAVE },
      crearCliente: (apiKey) => new Anthropic({ apiKey, maxRetries: 2 }),
      // Datos del partido (football-data.org) para que el análisis parta de números y gaste menos búsquedas.
      datosDePartido: env.FOOTBALL_DATA_KEY
        ? async ({ local, visitante, fecha }) => {
            const r = await datosPartido(
              new Request(
                "https://kal.local/api/datos-partido?" +
                  new URLSearchParams({ home: local, away: visitante, date: fecha }),
              ),
              { token: env.FOOTBALL_DATA_KEY, store: almacen(env) },
            );
            if (r.status === 429) return { limite: true };
            return r.ok ? r.json() : null;
          }
        : null,
    });
  return null;
}

export default {
  async fetch(request, env) {
    const { pathname } = new URL(request.url);
    const m = pathname.match(/^\/(?:\.netlify\/functions|api)\/([a-z-]+)\/?$/);
    if (m) {
      exponerVariables(env);
      try {
        const r = await api(m[1], request, env);
        if (r) return r;
      } catch (e) {
        return new Response(JSON.stringify({ error: "Error interno: " + (e?.message || "desconocido") }), {
          status: 500,
          headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
        });
      }
      return new Response(JSON.stringify({ error: "No existe esa función." }), {
        status: 404,
        headers: { "content-type": "application/json; charset=utf-8" },
      });
    }
    return env.ASSETS.fetch(request);
  },
  async scheduled(event, env, ctx) {
    ctx.waitUntil(
      enviarAvisos(almacen(env)).then((r) =>
        console.log(`avisos: ${r.telefonos} teléfono(s), ${r.enviados} aviso(s) enviados`),
      ),
    );
  },
};
